package br.com.isiflix.contah;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContahApplicationTests {

	@Test
	void contextLoads() {
	}

}

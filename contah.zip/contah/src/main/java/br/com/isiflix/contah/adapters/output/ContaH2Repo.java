package br.com.isiflix.contah.adapters.output;

import org.springframework.data.repository.CrudRepository;

public interface ContaH2Repo extends CrudRepository<ContaEntity, Integer>{

}

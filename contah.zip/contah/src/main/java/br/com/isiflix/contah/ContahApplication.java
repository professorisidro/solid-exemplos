package br.com.isiflix.contah;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContahApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContahApplication.class, args);
	}

}
